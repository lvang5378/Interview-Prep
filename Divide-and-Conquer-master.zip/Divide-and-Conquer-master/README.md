# Divide-and-Conquer

####The Divide and Conquer Paradigm
    1. DIVIDE into smaller sub-problems
    2. CONQUER via recursice calls
    3. COMBINE solutions of subproblems into one for the original problem 
    e.g. merge sort

####The Problem 
Input: array A containing the numbers 1, 2, 3, ..., n insome arbitrary order
Output: number of inversions = number of paris(i,j) of array indices with i  <j and A[i]> A[j]    

  Example: [1, 3, 5, 2, 4, 6]      return (3, 2)(5, 2)(5, 4)
    1, 2, 3, 4, 5, 6
    
    1, 3, 5, 2, 4, 6
    connect the same number and find croossing lines
    
#####Motivation: numerical similarity measure between two ranked list 
    (e. g. for "collaborating filtering") recommending system 
    
